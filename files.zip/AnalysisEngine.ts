/**
 * Chapter Analysis Engine
 * Orchestrates concept extraction, principle evaluation, and report generation
 */

import {
  Chapter,
  ChapterAnalysis,
  ConceptGraph,
  PrincipleEvaluation,
  AnalysisConfig,
  Recommendation,
  AnalysisVisualization,
} from './types';
import ConceptExtractor from './ConceptExtractor';
import {
  DeepProcessingEvaluator,
  SpacedRepetitionEvaluator,
  RetrievalPracticeEvaluator,
  InterleavingEvaluator,
  DualCodingEvaluator,
  GenerativeLearningEvaluator,
  MetacognitionEvaluator,
  SchemaBuildingEvaluator,
  CognitiveLoadEvaluator,
  EmotionAndRelevanceEvaluator,
} from './LearningPrincipleEvaluators';

// ============================================================================
// CHAPTER ANALYSIS ENGINE
// ============================================================================

export class AnalysisEngine {
  /**
   * Main entry point: Analyze a complete chapter
   */
  static async analyzeChapter(
    chapter: Chapter,
    config: AnalysisConfig
  ): Promise<ChapterAnalysis> {
    // Step 1: Extract concepts and build knowledge graph
    const conceptGraph = await ConceptExtractor.extractConceptsFromChapter(
      chapter.content,
      chapter.sections
    );

    // Step 2: Evaluate all learning principles
    const principles = this.evaluateAllPrinciples(chapter, conceptGraph, config);

    // Step 3: Analyze specific aspects
    const conceptAnalysis = this.analyzeConceptStructure(conceptGraph, chapter);
    const structureAnalysis = this.analyzeChapterStructure(chapter, conceptGraph);

    // Step 4: Generate recommendations
    const recommendations = this.generateRecommendations(
      principles,
      conceptAnalysis,
      structureAnalysis,
      chapter
    );

    // Step 5: Create visualizations
    const visualizations = this.generateVisualizations(chapter, conceptGraph, principles);

    // Step 6: Calculate overall score
    const overallScore = this.calculateWeightedScore(principles);

    return {
      chapterId: chapter.id,
      timestamp: new Date(),
      overallScore,
      principles,
      conceptAnalysis,
      structureAnalysis,
      recommendations,
      visualizations,
    };
  }

  /**
   * Evaluate all 10 learning principles
   */
  private static evaluateAllPrinciples(
    chapter: Chapter,
    conceptGraph: ConceptGraph,
    config: AnalysisConfig
  ): PrincipleEvaluation[] {
    const principles: PrincipleEvaluation[] = [];

    // Create all evaluators
    const evaluators = [
      DeepProcessingEvaluator,
      SpacedRepetitionEvaluator,
      RetrievalPracticeEvaluator,
      InterleavingEvaluator,
      DualCodingEvaluator,
      GenerativeLearningEvaluator,
      MetacognitionEvaluator,
      SchemaBuildingEvaluator,
      CognitiveLoadEvaluator,
      EmotionAndRelevanceEvaluator,
    ];

    evaluators.forEach((Evaluator) => {
      const evaluation = Evaluator.evaluate(chapter, conceptGraph);
      principles.push(evaluation);
    });

    return principles;
  }

  /**
   * Analyze concept structure
   */
  private static analyzeConceptStructure(
    conceptGraph: ConceptGraph,
    chapter: Chapter
  ) {
    const totalConcepts = conceptGraph.concepts.length;
    const mentions = conceptGraph.concepts.map((c) => c.mentions.length);
    const avgMentions =
      mentions.length > 0 ? mentions.reduce((a, b) => a + b, 0) / mentions.length : 0;
    const conceptDensity = (totalConcepts / chapter.wordCount) * 1000;

    const orphanConcepts = conceptGraph.concepts
      .filter((c) => conceptGraph.relationships.filter((r) => r.source === c.id || r.target === c.id).length === 0)
      .map((c) => c.id);

    const novelConceptsPerSection = chapter.sections.map((section) => {
      return conceptGraph.concepts.filter(
        (c) =>
          c.firstMentionPosition >= section.startPosition &&
          c.firstMentionPosition <= section.endPosition
      ).length;
    });

    const reviewPatterns = conceptGraph.concepts.map((concept) => {
      const mentions = concept.mentions.map((m) => m.position);
      const spacing: number[] = [];

      for (let i = 1; i < mentions.length; i++) {
        spacing.push(mentions[i] - mentions[i - 1]);
      }

      const avgSpacing = spacing.length > 0 ? spacing.reduce((a, b) => a + b) / spacing.length : 0;
      // Optimal spacing is 3-5 mentions, so gaps should be ~chapter.length / 4
      const isOptimal =
        spacing.length > 0 &&
        avgSpacing > chapter.wordCount * 0.05 &&
        avgSpacing < chapter.wordCount * 0.4;

      return {
        conceptId: concept.id,
        mentions: mentions.length,
        spacing,
        avgSpacing,
        isOptimal,
        recommendation: isOptimal
          ? undefined
          : mentions.length < 2
          ? 'Revisit concept more often'
          : 'Spread mentions more evenly',
      };
    });

    const hierarchyBalance = this.calculateHierarchyBalance(conceptGraph);

    return {
      totalConceptsIdentified: totalConcepts,
      coreConceptCount: conceptGraph.hierarchy.core.length,
      conceptDensity: parseFloat(conceptDensity.toFixed(2)),
      novelConceptsPerSection,
      reviewPatterns,
      hierarchyBalance,
      orphanConcepts,
    };
  }

  /**
   * Analyze chapter structure
   */
  private static analyzeChapterStructure(
    chapter: Chapter,
    conceptGraph: ConceptGraph
  ) {
    const sectionLengths = chapter.sections.map((s) => s.wordCount);
    const avgSectionLength =
      sectionLengths.reduce((a, b) => a + b, 0) / sectionLengths.length;

    // Calculate variance
    const variance =
      sectionLengths.reduce((sum, len) => sum + Math.pow(len - avgSectionLength, 2), 0) /
      sectionLengths.length;
    const stdDev = Math.sqrt(variance);
    const coefficientOfVariation = stdDev / avgSectionLength;

    const pacing =
      avgSectionLength > 800 ? 'slow' : avgSectionLength < 300 ? 'fast' : 'moderate';

    // Scaffolding analysis
    const hasIntroduction = chapter.sections[0]?.heading?.toLowerCase().includes('introduc');
    const hasProgression = conceptGraph.hierarchy.core.length > 0;
    const hasSummary = chapter.sections.some((s) =>
      s.heading?.toLowerCase().match(/summary|conclusion|recap/)
    );
    const hasReview = chapter.content.includes('review') || chapter.content.includes('recap');

    const scaffolding = {
      hasIntroduction: hasIntroduction ?? false,
      hasProgression,
      hasSummary: hasSummary ?? false,
      hasReview,
      scaffoldingScore:
        (Number(hasIntroduction) +
          Number(hasProgression) +
          Number(hasSummary) +
          Number(hasReview)) /
        4,
    };

    // Transition quality
    const transitionQuality = this.analyzeTransitionQuality(chapter);

    return {
      sectionCount: chapter.sections.length,
      avgSectionLength: parseFloat(avgSectionLength.toFixed(0)),
      sectionLengthVariance: parseFloat(coefficientOfVariation.toFixed(2)),
      pacing,
      scaffolding,
      transitionQuality,
      conceptualization:
        conceptGraph.hierarchy.core.length >= 5
          ? 'deep'
          : conceptGraph.hierarchy.core.length >= 2
          ? 'moderate'
          : 'shallow',
    };
  }

  /**
   * Generate recommendations based on evaluations
   */
  private static generateRecommendations(
    principles: PrincipleEvaluation[],
    conceptAnalysis: any,
    structureAnalysis: any,
    chapter: Chapter
  ): Recommendation[] {
    const recommendations: Recommendation[] = [];

    // Collect all suggestions from principle evaluations
    principles.forEach((principle) => {
      principle.suggestions.forEach((suggestion) => {
        if (suggestion.priority === 'high') {
          recommendations.push({
            id: suggestion.id,
            priority: suggestion.priority,
            category: 'enhance',
            title: suggestion.title,
            description: suggestion.description,
            affectedSections: [],
            affectedConcepts: suggestion.relatedConcepts,
            estimatedEffort: 'medium',
            expectedOutcome: suggestion.expectedImpact,
            actionItems: [suggestion.implementation],
          });
        }
      });
    });

    // Add structural recommendations
    if (structureAnalysis.avgSectionLength > 1000) {
      recommendations.push({
        id: 'struct-1',
        priority: 'high',
        category: 'restructure',
        title: 'Break Up Long Sections',
        description:
          'Some sections exceed 1000 words; consider breaking into smaller segments',
        affectedSections: chapter.sections
          .filter((s) => s.wordCount > 1000)
          .map((s) => s.id),
        affectedConcepts: [],
        estimatedEffort: 'high',
        expectedOutcome: 'Reduced cognitive load; improved retention',
        actionItems: [
          'Identify natural breaking points',
          'Add subheadings',
          'Create checkpoint questions between segments',
        ],
      });
    }

    if (conceptAnalysis.orphanConcepts.length > 0) {
      recommendations.push({
        id: 'concept-1',
        priority: 'medium',
        category: 'clarify',
        title: 'Connect Isolated Concepts',
        description: `${conceptAnalysis.orphanConcepts.length} concepts lack connections to related ideas`,
        affectedSections: [],
        affectedConcepts: conceptAnalysis.orphanConcepts,
        estimatedEffort: 'medium',
        expectedOutcome: 'Stronger knowledge networks; better retention',
        actionItems: [
          'Identify relationships between orphan concepts and others',
          'Add transition sentences or examples showing connections',
        ],
      });
    }

    // Sort by priority
    return recommendations.sort((a, b) => {
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });
  }

  /**
   * Generate visualization data
   */
  private static generateVisualizations(
    chapter: Chapter,
    conceptGraph: ConceptGraph,
    principles: PrincipleEvaluation[]
  ): AnalysisVisualization {
    return {
      conceptMap: this.generateConceptMapData(conceptGraph),
      cognitiveLoadCurve: this.generateCognitiveLoadCurve(chapter, conceptGraph),
      interleavingPattern: this.generateInterleavingPattern(chapter, conceptGraph),
      reviewSchedule: this.generateReviewSchedule(conceptGraph),
      principleScores: this.generatePrincipleScores(principles),
    };
  }

  private static generateConceptMapData(conceptGraph: ConceptGraph) {
    const nodes = conceptGraph.concepts.map((concept, idx) => {
      const colorMap = { core: '#FF6B6B', supporting: '#4ECDC4', detail: '#95E1D3' };
      return {
        id: concept.id,
        label: concept.name,
        importance: concept.importance,
        size: Math.min(30, 10 + concept.mentions.length * 2),
        color: colorMap[concept.importance],
        firstMention: concept.firstMentionPosition,
      };
    });

    const links = conceptGraph.relationships.slice(0, Math.min(conceptGraph.relationships.length, 20)).map((rel) => ({
      source: rel.source,
      target: rel.target,
      type: rel.type,
      strength: rel.strength,
    }));

    const clusters = this.createConceptClusters(nodes, conceptGraph);

    return { nodes, links, clusters };
  }

  private static generateCognitiveLoadCurve(
    chapter: Chapter,
    conceptGraph: ConceptGraph
  ) {
    return chapter.sections.map((section, idx) => {
      const novConceptsInSection = conceptGraph.concepts.filter(
        (c) =>
          c.firstMentionPosition >= section.startPosition &&
          c.firstMentionPosition <= section.endPosition
      ).length;

      const conceptDensity = novConceptsInSection / (section.wordCount / 100);
      const sentenceComplexity = (section.wordCount / section.content.split(/[.!?]/).length) * 10;

      return {
        sectionId: section.id,
        position: (section.startPosition + section.endPosition) / 2,
        load: Math.min((novConceptsInSection * 0.1 + sentenceComplexity * 0.05) / 100, 1),
        factors: {
          novelConcepts: novConceptsInSection,
          conceptDensity: parseFloat(conceptDensity.toFixed(2)),
          sentenceComplexity: parseFloat(sentenceComplexity.toFixed(0)),
          technicalTerms: (section.content.match(/[A-Z][a-z]+/g) || []).length,
        },
      };
    });
  }

  private static generateInterleavingPattern(
    chapter: Chapter,
    conceptGraph: ConceptGraph
  ) {
    const blockingSegments = [];
    let current = {
      concept: conceptGraph.sequence[0],
      length: 1,
      startPosition: 0,
    };

    for (let i = 1; i < conceptGraph.sequence.length; i++) {
      if (conceptGraph.sequence[i] === current.concept) {
        current.length++;
      } else {
        if (current.length > 2) {
          blockingSegments.push({
            startPosition: current.startPosition,
            endPosition: i,
            conceptId: current.concept,
            length: current.length,
            issue: `Concept ${current.concept} appears ${current.length} times consecutively`,
          });
        }
        current = {
          concept: conceptGraph.sequence[i],
          length: 1,
          startPosition: i,
        };
      }
    }

    const blockingRatio =
      blockingSegments.length > 0
        ? blockingSegments.reduce((sum, seg) => sum + seg.length, 0) /
          conceptGraph.sequence.length
        : 0;

    return {
      conceptSequence: conceptGraph.sequence.slice(0, 20), // First 20 for viz
      blockingSegments,
      blockingRatio,
      topicSwitches: conceptGraph.sequence.filter(
        (c, i) => i === 0 || c !== conceptGraph.sequence[i - 1]
      ).length,
      avgBlockSize:
        blockingSegments.length > 0
          ? blockingSegments.reduce((sum, seg) => sum + seg.length, 0) /
            blockingSegments.length
          : 1,
      recommendation:
        blockingRatio > 0.6
          ? 'Consider more interleaving'
          : 'Good topic mixing detected',
    };
  }

  private static generateReviewSchedule(conceptGraph: ConceptGraph) {
    const concepts = conceptGraph.concepts
      .filter((c) => c.mentions.length > 1)
      .map((c) => {
        const spacing = [];
        for (let i = 1; i < c.mentions.length; i++) {
          spacing.push(c.mentions[i].position - c.mentions[i - 1].position);
        }
        return {
          conceptId: c.id,
          mentions: c.mentions.length,
          spacing,
          isOptimal:
            spacing.length > 0 &&
            spacing.every(
              (gap) => gap > 1000 && gap < 10000 // Heuristic thresholds
            ),
        };
      });

    const avgSpacing =
      concepts.length > 0
        ? concepts.reduce(
            (sum, c) =>
              sum +
              (c.spacing.length > 0
                ? c.spacing.reduce((a, b) => a + b) / c.spacing.length
                : 0),
            0
          ) / concepts.length
        : 0;

    return {
      concepts,
      optimalSpacing: Math.round(avgSpacing),
      currentAvgSpacing: Math.round(avgSpacing),
    };
  }

  private static generatePrincipleScores(principles: PrincipleEvaluation[]) {
    const principleNames: Record<string, string> = {
      deepProcessing: 'Deep Processing',
      spacedRepetition: 'Spaced Repetition',
      retrievalPractice: 'Retrieval Practice',
      interleaving: 'Interleaving',
      dualCoding: 'Dual Coding',
      generativeLearning: 'Generative Learning',
      metacognition: 'Metacognition',
      schemaBuilding: 'Schema Building',
      cognitiveLoad: 'Cognitive Load',
      emotionAndRelevance: 'Emotion & Relevance',
    };

    const principleData = principles.map((p) => ({
      name: p.principle,
      displayName: principleNames[p.principle],
      score: p.score,
      weight: p.weight,
    }));

    const overallWeightedScore =
      principleData.reduce((sum, p) => sum + p.score * p.weight, 0) /
      principleData.reduce((sum, p) => sum + p.weight, 0);

    const sorted = [...principleData].sort((a, b) => b.score - a.score);

    return {
      principles: principleData,
      overallWeightedScore: parseFloat(overallWeightedScore.toFixed(1)),
      strongestPrinciples: sorted.slice(0, 3).map((p) => p.name),
      weakestPrinciples: sorted.slice(-3).map((p) => p.name),
    };
  }

  private static createConceptClusters(nodes: any[], conceptGraph: ConceptGraph) {
    // Simple clustering: group by importance
    const clusters = [
      {
        id: 'core',
        conceptIds: conceptGraph.hierarchy.core.map((c) => c.id),
        theme: 'Core Concepts',
        centroid: { x: -50, y: 0 },
      },
      {
        id: 'supporting',
        conceptIds: conceptGraph.hierarchy.supporting.map((c) => c.id),
        theme: 'Supporting Concepts',
        centroid: { x: 0, y: 50 },
      },
      {
        id: 'detail',
        conceptIds: conceptGraph.hierarchy.detail.map((c) => c.id),
        theme: 'Details',
        centroid: { x: 50, y: 0 },
      },
    ];

    return clusters;
  }

  private static analyzeTransitionQuality(chapter: Chapter): number {
    let quality = 0.5;

    const transitionPhrases = [
      'furthermore',
      'however',
      'therefore',
      'meanwhile',
      'notably',
      'importantly',
      'in conclusion',
      'for example',
      'similarly',
      'in contrast',
    ];

    const foundTransitions = transitionPhrases.filter((phrase) =>
      chapter.content.toLowerCase().includes(phrase)
    );

    quality += (foundTransitions.length / transitionPhrases.length) * 0.3;

    return Math.min(quality, 1);
  }

  private static calculateHierarchyBalance(conceptGraph: ConceptGraph): number {
    const total = conceptGraph.concepts.length;
    const coreRatio = conceptGraph.hierarchy.core.length / total;
    const supportingRatio = conceptGraph.hierarchy.supporting.length / total;

    // Ideal: 20% core, 30% supporting, 50% detail
    const coreDeviation = Math.abs(coreRatio - 0.2);
    const supportingDeviation = Math.abs(supportingRatio - 0.3);

    return Math.max(1 - (coreDeviation + supportingDeviation) / 2, 0);
  }

  private static calculateWeightedScore(principles: PrincipleEvaluation[]): number {
    const total = principles.reduce((sum, p) => sum + p.score * p.weight, 0);
    const weightSum = principles.reduce((sum, p) => sum + p.weight, 0);
    return parseFloat((total / weightSum).toFixed(1));
  }
}

export default AnalysisEngine;

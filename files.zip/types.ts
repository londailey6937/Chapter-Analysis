/**
 * Core Data Types for Chapter Checker
 * Defines the structure for concepts, chapters, analyses, and recommendations
 */

// ============================================================================
// CONCEPT & KNOWLEDGE STRUCTURE
// ============================================================================

export interface Concept {
  id: string;
  name: string;
  definition: string;
  importance: 'core' | 'supporting' | 'detail';
  firstMentionPosition: number; // Character position in chapter
  mentions: ConceptMention[];
  relatedConcepts: string[]; // IDs of related concepts
  prerequisites: string[]; // Concept IDs that must come first
  applications: string[]; // Real-world uses
  commonMisconceptions: string[];
  emoji?: string;
}

export interface ConceptMention {
  position: number; // Character position
  context: string; // Surrounding text (200 chars)
  depth: 'shallow' | 'moderate' | 'deep'; // How thoroughly explained
  isRevisit: boolean;
  associatedConcepts: string[]; // Other concepts mentioned nearby
}

export interface ConceptGraph {
  concepts: Concept[];
  relationships: ConceptRelationship[];
  hierarchy: ConceptHierarchy;
  sequence: string[]; // Order of first mentions
}

export interface ConceptRelationship {
  source: string; // Concept ID
  target: string; // Concept ID
  type: 'prerequisite' | 'related' | 'contrasts' | 'extends' | 'example';
  strength: number; // 0-1, how strongly related
}

export interface ConceptHierarchy {
  core: Concept[];
  supporting: Concept[];
  detail: Concept[];
}

// ============================================================================
// CHAPTER STRUCTURE
// ============================================================================

export interface Chapter {
  id: string;
  title: string;
  content: string;
  wordCount: number;
  sections: Section[];
  conceptGraph: ConceptGraph;
  metadata: ChapterMetadata;
}

export interface Section {
  id: string;
  heading: string;
  content: string;
  startPosition: number;
  endPosition: number;
  wordCount: number;
  conceptsIntroduced: string[]; // Concept IDs
  conceptsRevisited: string[];
  depth: number; // Nesting level
}

export interface ChapterMetadata {
  readingLevel: 'beginner' | 'intermediate' | 'advanced';
  domain: string; // e.g., "physics", "writing", "history"
  targetAudience: string;
  estimatedReadingTime: number; // minutes
  createdAt: Date;
  lastAnalyzed: Date;
}

// ============================================================================
// LEARNING PRINCIPLE EVALUATION
// ============================================================================

export interface PrincipleEvaluation {
  principle: LearningPrinciple;
  score: number; // 0-100
  weight: number; // How important for this domain
  findings: Finding[];
  suggestions: Suggestion[];
  evidence: Evidence[];
}

export type LearningPrinciple =
  | 'deepProcessing'
  | 'spacedRepetition'
  | 'retrievalPractice'
  | 'interleaving'
  | 'dualCoding'
  | 'generativeLearning'
  | 'metacognition'
  | 'schemaBuilding'
  | 'cognitiveLoad'
  | 'emotionAndRelevance';

export interface Finding {
  type: 'positive' | 'warning' | 'neutral' | 'critical';
  message: string;
  severity: number; // 0-1
  location?: {
    sectionId: string;
    position: number;
  };
  evidence: string; // Quote or reference from text
}

export interface Suggestion {
  id: string;
  principle: LearningPrinciple;
  priority: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  implementation: string; // How to implement
  expectedImpact: string; // What will improve
  relatedConcepts: string[]; // Concept IDs this affects
  examples?: string[];
}

export interface Evidence {
  type: 'count' | 'metric' | 'pattern' | 'absence';
  metric: string; // e.g., "concept_revisits", "question_count"
  value: number | string;
  threshold?: number; // Ideal value
  quality: 'strong' | 'moderate' | 'weak';
}

// ============================================================================
// ANALYSIS RESULTS
// ============================================================================

export interface ChapterAnalysis {
  chapterId: string;
  timestamp: Date;
  overallScore: number; // 0-100, weighted average
  principles: PrincipleEvaluation[];
  conceptAnalysis: ConceptAnalysisResult;
  structureAnalysis: StructureAnalysisResult;
  recommendations: Recommendation[];
  visualizations: AnalysisVisualization;
}

export interface ConceptAnalysisResult {
  totalConceptsIdentified: number;
  coreConceptCount: number;
  conceptDensity: number; // Concepts per 1000 words
  novelConceptsPerSection: number[];
  reviewPatterns: ReviewPattern[];
  hierarchyBalance: number; // 0-1, how well balanced
  orphanConcepts: string[]; // Concepts with no connections
}

export interface ReviewPattern {
  conceptId: string;
  mentions: number;
  firstAppearance: number; // Character position
  spacing: number[]; // Gaps between mentions
  avgSpacing: number;
  isOptimal: boolean;
  recommendation?: string;
}

export interface StructureAnalysisResult {
  sectionCount: number;
  avgSectionLength: number;
  sectionLengthVariance: number;
  pacing: 'slow' | 'moderate' | 'fast';
  scaffolding: ScaffoldingAnalysis;
  transitionQuality: number; // 0-1
  conceptualization: 'shallow' | 'moderate' | 'deep';
}

export interface ScaffoldingAnalysis {
  hasIntroduction: boolean;
  hasProgression: boolean;
  hasSummary: boolean;
  hasReview: boolean;
  scaffoldingScore: number; // 0-1
}

export interface Recommendation {
  id: string;
  priority: 'high' | 'medium' | 'low';
  category: 'restructure' | 'enhance' | 'add' | 'clarify' | 'remove';
  title: string;
  description: string;
  affectedSections: string[]; // Section IDs
  affectedConcepts: string[]; // Concept IDs
  estimatedEffort: 'low' | 'medium' | 'high';
  expectedOutcome: string;
  actionItems: string[];
}

// ============================================================================
// VISUALIZATIONS
// ============================================================================

export interface AnalysisVisualization {
  conceptMap: ConceptMapData;
  cognitiveLoadCurve: CognitiveLoadPoint[];
  interleavingPattern: InterleavingData;
  reviewSchedule: ReviewScheduleData;
  principleScores: PrincipleScoreData;
}

export interface ConceptMapData {
  nodes: ConceptNode[];
  links: ConceptLink[];
  clusters: ConceptCluster[];
}

export interface ConceptNode {
  id: string;
  label: string;
  importance: 'core' | 'supporting' | 'detail';
  size: number; // Based on mention frequency
  color: string; // Based on introduction order or domain
  firstMention: number; // Position in chapter
}

export interface ConceptLink {
  source: string; // Node ID
  target: string; // Node ID
  type: 'prerequisite' | 'related' | 'contrasts' | 'extends' | 'example';
  strength: number; // Line thickness
}

export interface ConceptCluster {
  id: string;
  conceptIds: string[];
  theme: string; // e.g., "Foundational", "Application"
  centroid: { x: number; y: number };
}

export interface CognitiveLoadPoint {
  sectionId: string;
  position: number; // Character position
  load: number; // 0-1, estimated cognitive load
  factors: {
    novelConcepts: number;
    conceptDensity: number;
    sentenceComplexity: number;
    technicalTerms: number;
  };
}

export interface InterleavingData {
  conceptSequence: string[]; // Concept IDs in order
  blockingSegments: BlockingSegment[];
  blockingRatio: number; // 0-1, how much is "blocked"
  topicSwitches: number;
  avgBlockSize: number;
  recommendation: string;
}

export interface BlockingSegment {
  startPosition: number;
  endPosition: number;
  conceptId: string;
  length: number;
  issue: string;
}

export interface ReviewScheduleData {
  concepts: ReviewConcept[];
  optimalSpacing: number; // Ideal gap between mentions
  currentAvgSpacing: number;
}

export interface ReviewConcept {
  conceptId: string;
  mentions: number;
  spacing: number[];
  isOptimal: boolean;
}

export interface PrincipleScoreData {
  principles: {
    name: LearningPrinciple;
    displayName: string;
    score: number; // 0-100
    weight: number;
  }[];
  overallWeightedScore: number;
  strongestPrinciples: LearningPrinciple[];
  weakestPrinciples: LearningPrinciple[];
}

// ============================================================================
// UTILITIES
// ============================================================================

export interface AnalysisConfig {
  domain: string;
  readingLevel: 'beginner' | 'intermediate' | 'advanced';
  focusPrinciples?: LearningPrinciple[];
  enableVisualization: boolean;
  conceptExtractionThreshold: number; // Confidence threshold (0-1)
  detailedReport: boolean;
}

export interface ExportData {
  format: 'json' | 'markdown' | 'html';
  includeVisualizations: boolean;
  includeSuggestions: boolean;
  includeEvidence: boolean;
}

// Type guards
export function isPrincipleEvaluation(obj: any): obj is PrincipleEvaluation {
  return 'principle' in obj && 'score' in obj && 'findings' in obj;
}

export function isChapterAnalysis(obj: any): obj is ChapterAnalysis {
  return 'chapterId' in obj && 'principles' in obj && 'overallScore' in obj;
}
